package Controllers;

import javafx.embed.swing.JFXPanel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * Created by Morco on 12/6/2017.
 */
public class DrawAvatar {

    @FXML
    private Button submitBtn, goBackBtn;

    public void submitAndBack(ActionEvent event)throws Exception{
        //This is the action for logout button, user can logout by this button and go back to the login page

        Stage currentStage = (Stage) submitBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/profile.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void goBack(ActionEvent event)throws Exception{
        //This is the action for logout button, user can logout by this button and go back to the login page

        Stage currentStage = (Stage) goBackBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/profile.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
