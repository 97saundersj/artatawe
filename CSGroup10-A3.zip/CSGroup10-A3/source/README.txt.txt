Step 1. Put the Artatawe Package into Eclipse
Step 2. Open the Controllers package
Step 3. Run the ArtataweMain.java
Step 4. Compile it
