package Controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;

/**
 * The page for user to upload their artwork into the system
 * 
 * @Author Marco
 */
public class ArtworkUpload {
	private Database database; // calls the back-end to help with implementation
	private FileChooser fileChooser = new FileChooser();
	private ObservableList<String> chooseTypeList = FXCollections.observableArrayList("Painting", "Sculpture");

	@FXML
	private Label warningMsg;

	@FXML
	private TextField title, price, filePath, year, width, height, noOfBid, material, depth;

	@FXML
	private TextArea description;

	@FXML
	private Button goBackBtn, logoutBtn, browsArtBtn, uploadArtBtn;

	@FXML
	private ChoiceBox chooseTypeBox;

	/**
	 * sets the database
	 * 
	 * @param database
	 */

	public void setDatabase(Database database) {
		this.database = database;
	}

	/**
	 * this is the action of logout and back to login screen by LOGOUT button
	 * 
	 * @throws Exception
	 */
	@FXML
	public void logout() throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
		Stage currentStage = (Stage) logoutBtn.getScene().getWindow();
		currentStage.close();
		Stage stage = new Stage();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * this is the action of going back to previous page the searching screen by
	 * the GO BACK button
	 * 
	 * @throws Exception
	 */
	@FXML
	public void goBackPreviousPage() throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("../gui/home.fxml"));
		Stage currentStage = (Stage) goBackBtn.getScene().getWindow();
		currentStage.close();
		Stage stage = new Stage();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * this is the action of uploading an artwork by browsing the file in local
	 * system
	 * 
	 * @throws Exception
	 */
	@FXML
	public void browseImage() throws Exception {
		// this is the action of uploading an artwork by browsing the file in
		// local system
		Stage stage = new Stage();
		fileChooser.setTitle("Open Image File");
		fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("All Images", "*.*"),
				new FileChooser.ExtensionFilter("JPG", "*.jpg"), new FileChooser.ExtensionFilter("PNG", "*.png"));
		File file = fileChooser.showOpenDialog(stage);
		if (file != null) {
			String filePathString = file.toString();

			filePath.setText(filePathString);
		} else {
			filePath.setText(null);
		}
	}

	/**
	 * this is the action for uploading an artwork through button
	 * 
	 * @throws Exception
	 */
	@FXML
	public void uploadArtWork() throws Exception {
		filePath.setText(filePath.getText().replace("\\", "/"));
		if (!title.getText().isEmpty() && !price.getText().isEmpty() && !filePath.getText().isEmpty()) {
			try {
				double value = Double.parseDouble(price.getText());
				double priceValue = value;
				price.setText(String.valueOf(priceValue));
			} catch (Exception e) {
				System.out.println("price should be number!!!");
				warningMsg.setText("Reserve price need to be a number.");
			}
			// implementing filters
			if (chooseTypeBox.getValue().equals("Painting")) {
				Database.manageArtwork().addPainting(title.getText(), description.getText(), filePath.getText(),
						Database.getProfile(), Integer.parseInt(year.getText()),
						(int) Double.parseDouble(price.getText()), Integer.parseInt(noOfBid.getText()),
						Integer.parseInt(width.getText()), Integer.parseInt(height.getText()));
			} else {
				Database.manageArtwork().addSculpture(title.getText(), description.getText(), filePath.getText(),
						Database.getProfile(), Integer.parseInt(year.getText()),
						(int) Double.parseDouble(price.getText()), Integer.parseInt(noOfBid.getText()),
						Integer.parseInt(width.getText()), Integer.parseInt(height.getText()),
						Integer.parseInt(depth.getText()), material.getText());
			}
		} else {
			System.out.println("something is empty!!");
			warningMsg.setText("All information are needed to be filled");
		}
	}

	/**
	 * this is for setting option for the choicebox
	 */
	@FXML
	private void initialize() {
		chooseTypeBox.setValue("Painting");
		chooseTypeBox.setItems(chooseTypeList);
	}
}
