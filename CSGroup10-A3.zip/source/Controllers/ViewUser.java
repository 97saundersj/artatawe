package Controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * This is the class for viewing other users' information
 * 
 * @Author Marco
 */
public class ViewUser {

	private Profile user;

	@FXML
	private Label userName;

	@FXML
	private ImageView avatar;

	@FXML
	private Button closeBtn;

	/**
	 * This is the action for Home button, user can back to home page by this
	 * button
	 * 
	 * @throws Exception
	 */
	@FXML
	public void closeWindow() throws Exception {
		Stage currentStage = (Stage) closeBtn.getScene().getWindow();
		currentStage.close();
	}

	/**
	 * sets the user that the class will load the data of, for viewing users
	 * 
	 * @param user
	 */
	public void setUser(Profile user) {
		this.user = user;
		userName.setText(user.getUserName());
	}

	@FXML
	private void initialize() throws Exception {

	}

}
