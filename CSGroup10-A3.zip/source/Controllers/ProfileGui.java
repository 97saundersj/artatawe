package Controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * The Profile page of user, showing different information
 * 
 * @Author Marco
 *
 */
public class ProfileGui {

	@FXML
	private Label firstName, lastName, adress, phoneNo, postCode, userName;

	@FXML
	private ImageView avatar;

	@FXML
	private Button homeBtn, logoutBtn;

	@FXML
	private ListView artworkList, favUserList, bidWonList, bidPlacedList;

	/**
	 * This is the action for logout button, user can logout by this button and
	 * go back to the login page
	 * 
	 * @throws Exception
	 */
	@FXML
	public void logout() throws Exception {
		Stage currentStage = (Stage) logoutBtn.getScene().getWindow();
		currentStage.close();
		Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
		Stage stage = new Stage();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * This is the action for Home button, user can back to home page by this
	 * button
	 * 
	 * @throws Exception
	 */
	@FXML
	public void switchBackhome() throws Exception {
		Stage currentStage = (Stage) homeBtn.getScene().getWindow();
		currentStage.close();
		Parent root = FXMLLoader.load(getClass().getResource("../gui/home.fxml"));
		Stage stage = new Stage();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * this is the mouse click event for user to double the list item to get in
	 * to viewing page
	 * 
	 * @param arg0
	 *            clicking action
	 * @throws Exception
	 */
	@FXML
	public void artworkOwnViewMouseClick(MouseEvent arg0) throws Exception {
		if (arg0.getClickCount() == 2) {
			System.out.println("clicked on " + artworkList.getSelectionModel().getSelectedItem());
			Parent root = FXMLLoader.load(getClass().getResource("../gui/viewOwnArt.fxml"));
			Stage stage = new Stage();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		}
	}

	/**
	 * this is the mouse click event for user to double the list item to get in
	 * to viewing page
	 * 
	 * @param click
	 * @throws Exception
	 */
	public void artworkViewMouseClick(MouseEvent click) throws Exception {
		if (click.getClickCount() == 2) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("../gui/viewArt.fxml"));

			Stage stage = new Stage();
			stage.setScene(new Scene((Pane) loader.load()));

			ArtworkView controller = loader.<ArtworkView>getController();
			controller.setArtwork(Database.manageArtwork()
					.getArtworkByTitle(bidWonList.getSelectionModel().getSelectedItem().toString()).get(0));

			stage.show();
		}
	}

	/**
	 * this is the mouse click event for user to double the list item to get in
	 * to viewing page
	 * 
	 * @param arg0
	 * @throws Exception
	 */
	@FXML
	public void favUserViewMouseClick(MouseEvent arg0) throws Exception {
		if (arg0.getClickCount() == 2) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("../gui/viewUser.fxml"));
			Stage stage = new Stage();
			stage.setScene(new Scene((Pane) loader.load()));
			ViewUser controller = loader.<ViewUser>getController();
			controller.setUser(Database.manageProfiles()
					.searchProfile(favUserList.getSelectionModel().getSelectedItem().toString()));
			stage.show();
		}
	}

	@FXML
	private void initialize() throws Exception {
		Profile profile = Database.getProfile();
		bidWonList.getItems().addAll(profile.getArtworksWon());
		artworkList.getItems().addAll(Database.manageArtwork().getArtworkByProfile(profile));
		favUserList.getItems().addAll(profile.getFavourites());
		bidPlacedList.getItems().addAll(Database.manageBids().getBidByProfile(profile));
		userName.setText(profile.getUserName());
		postCode.setText(profile.getPostCode());
		firstName.setText(profile.getFirstName());
		lastName.setText(profile.getLastName());
		phoneNo.setText(profile.getPhoneNo());
		adress.setText(profile.getAddress());
		avatar.setImage(Database.convertPathToImage(profile.getProfilePicPath()));
	}

}
