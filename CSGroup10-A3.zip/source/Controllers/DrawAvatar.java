package Controllers;

import java.io.File;

import javax.imageio.ImageIO;

import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.TextField;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * This gui class allow user to draw their own avatar with different colors,
 * brush size and a eraser function
 * 
 * @Author Marco
 */
public class DrawAvatar {
	@FXML
	private TextField brushSize;

	@FXML
	private Button submitBtn, cancelBtn;

	@FXML
	private Canvas drawingCanvas;

	@FXML
	private ColorPicker colorPicker;

	@FXML
	private CheckBox eraser;

	private Profile user;

	/**
	 * sets the Profile user
	 * 
	 * @param username
	 */
	public void setUser(Profile username) {
		this.user = username;
	}

	/**
	 * This is the action for Submit button, user can submit the avatar by this
	 * button
	 */
	public void submitAndBack() {
		try {
			WritableImage snapshot = drawingCanvas.snapshot(new SnapshotParameters(), null);
			File file = new File("src/CustomImages/" + user.getUserName() + ".jpg");
			user.setProfilePicPath("CustomImages/" + user.getUserName() + ".jpg");
			ImageIO.write(SwingFXUtils.fromFXImage(snapshot, null), "jpg", file);
			Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
			Stage stage = new Stage();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
			Stage currentStage = (Stage) cancelBtn.getScene().getWindow();
			currentStage.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * This is the action for Cancel button, user can shut down the drawing page
	 * by this button
	 * 
	 * @throws Exception
	 */
	public void cancelAndShutDown() throws Exception {
		// This is the action for Cancel button, user can shut down the drawing
		// page by this button
		Stage currentStage = (Stage) cancelBtn.getScene().getWindow();
		currentStage.close();
	}

	/**
	 * this is the method of painting own avatar for user
	 */
	public void initialize() {
		GraphicsContext g = drawingCanvas.getGraphicsContext2D();
		drawingCanvas.setOnMouseDragged(e -> {
			double size = Double.parseDouble(brushSize.getText());
			double x = e.getX() - size / 2;
			double y = e.getY() - size / 2;
			if (eraser.isSelected()) {
				g.clearRect(x, y, size, size);
			} else {
				g.setFill(colorPicker.getValue());
				g.fillRoundRect(x, y, size, size, size, size);
			}
		});
	}
}
