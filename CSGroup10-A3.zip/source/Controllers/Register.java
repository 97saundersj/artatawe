package Controllers;

import javafx.scene.control.Label;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * The Register Gui, for user's registration
 * 
 * @Author Marco TODO Need to register username to database
 */
public class Register {

	@FXML
	private Label warningMsg;

	@FXML
	private TextField registerId, firstName, lastName, phoneNo, postCode, address;

	@FXML
	private Button closeBtn, submitBtn, pickPre, draw;

	/**
	 * the action of go back button, which for linking to the login interface
	 * 
	 * @throws Exception
	 */
	@FXML
	public void closeCurrentPage() throws Exception {
		// the action of go back button, which for linking to the login
		// interface
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../gui/login.fxml"));
		Stage stage = new Stage();
		stage.setScene(new Scene((Pane) loader.load()));
		stage.show();
		Stage currentStage = (Stage) draw.getScene().getWindow();
		currentStage.close();
	}

	/**
	 * moves the screen to predefined images
	 * 
	 * @throws Exception
	 */
	public void goToPre() throws Exception {
		Database.manageProfiles().addProfile(lastName.getText(), firstName.getText(), registerId.getText(),
				phoneNo.getText(), address.getText(), postCode.getText(), null);
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../gui/defaultAvatar.fxml"));
		Stage stage = new Stage();
		stage.setScene(new Scene((Pane) loader.load()));
		BuildInAvatar controller = loader.<BuildInAvatar>getController();
		controller.setUser(
				Database.manageProfiles().getProfiles().get(Database.manageProfiles().getProfiles().size() - 1));
		stage.show();
		Stage currentStage = (Stage) draw.getScene().getWindow();
		currentStage.close();
	}

	/**
	 * moves the screen to the draw screen ( allowing the user to create his own
	 * avatar)
	 * 
	 * @throws Exception
	 */
	public void draw() throws Exception {
		Database.manageProfiles().addProfile(lastName.getText(), firstName.getText(), registerId.getText(),
				phoneNo.getText(), address.getText(), postCode.getText(), null);
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../gui/draw.fxml"));
		Stage stage = new Stage();
		stage.setScene(new Scene((Pane) loader.load()));
		DrawAvatar controller = loader.<DrawAvatar>getController();
		controller.setUser(
				Database.manageProfiles().getProfiles().get(Database.manageProfiles().getProfiles().size() - 1));
		stage.show();
		Stage currentStage = (Stage) draw.getScene().getWindow();
		currentStage.close();
	}

	public void initialize() {

	}
}
