package Controllers;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;

import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * a class to store an Artwork, if the artwork is a sculpture the subclass of
 * artwork is used,
 * 
 * @author Alex
 */
public class Artwork {
	protected static int idList;
	protected final int id;
	protected String title;
	protected String description;
	protected String mainPhoto;
	protected ArrayList<String> allPhotos;
	protected Profile creator;
	protected int yearOfCreation;
	protected int reservePrice;
	protected int noOfBids;
	protected LocalDateTime startTime;
	protected int width;
	protected int height;
	protected Bid currentBid;
	protected String type;

	/**
	 * constructs a new artwork
	 * 
	 * @param title
	 * @param description
	 * @param mainPhoto
	 *            the path to the image
	 * @param creator
	 *            the profile who listed the art
	 * @param yearOfCreation
	 * @param reservePrice
	 * @param noOfBids
	 * @param width
	 * @param height
	 * @param startTime
	 */
	public Artwork(String title, String description, String mainPhoto, Profile creator, int yearOfCreation,
			int reservePrice, int noOfBids, int width, int height, LocalDateTime startTime) {
		idList++;
		id = idList;
		this.title = title;
		this.description = description;
		this.creator = creator;
		this.yearOfCreation = yearOfCreation;
		this.reservePrice = reservePrice;
		this.noOfBids = noOfBids;
		this.width = width;
		this.height = height;
		this.mainPhoto = mainPhoto;
		this.allPhotos = new ArrayList<String>();
		this.startTime = LocalDateTime.now();
		this.type = "Artwork";
	}

	/**
	 * returns all images of the picture that is stored
	 * 
	 * @return an arraylist with all images contained in it
	 */
	public ArrayList<String> getAllPhotos() {
		return allPhotos;
	}

	/**
	 * returns the reserve price of the artwork
	 * 
	 * @return int, the reserve price
	 */
	public int getReservePrice() {
		return reservePrice;
	}

	/**
	 * returns the number of bids currently avaliable
	 * 
	 * @return int, the number of bids
	 */
	public int getNoOfBids() {
		return noOfBids;
	}

	/**
	 * returns the start time
	 * 
	 * @return
	 */
	public LocalDateTime getStartTime() {
		return startTime;
	}

	/**
	 * returns the title
	 * 
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * sets the title
	 * 
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * returns the description
	 * 
	 * @return
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * sets the description
	 * 
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * gets the file path of the main picture
	 * 
	 * @return
	 */
	public String getMainPhoto() {
		return mainPhoto;
	}

	/**
	 * sets the file path of the main picture
	 * 
	 * @param mainPhoto
	 */
	public void setMainPhoto(String mainPhoto) {
		this.mainPhoto = mainPhoto;
	}

	/**
	 * gets the profile object of the creator, ie the lister
	 * 
	 * @return
	 */
	public Profile getCreator() {
		return creator;
	}

	/**
	 * sets the creator to a profile
	 * 
	 * @param creator
	 */
	public void setCreator(Profile creator) {
		this.creator = creator;
	}

	/**
	 * gets the year that the artwork was made
	 * 
	 * @return
	 */
	public int getYearOfCreation() {
		return yearOfCreation;
	}

	/**
	 * sets the year that the artwork was made
	 * 
	 * @param yearOfCreation
	 */
	public void setYearOfCreation(int yearOfCreation) {
		this.yearOfCreation = yearOfCreation;
	}

	/**
	 * gets the width
	 * 
	 * @return
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * sets the width
	 * 
	 * @param width
	 */
	public void setWidth(int width) {
		this.width = width;
	}

	/**
	 * gets the height
	 * 
	 * @return
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * sets the height
	 * 
	 * @param height
	 */
	public void setHeight(int height) {
		this.height = height;
	}

	/**
	 * adds an image to the artworks images
	 * 
	 * @param image
	 */
	public void addImageToArrayList(String image) {
		allPhotos.add(image);
	}

	/**
	 * gets the current highest bid on the artwork
	 * 
	 * @return a bid object of the highest bid on the artwork
	 */
	public Bid getCurrentBid() {
		return currentBid;
	}

	/**
	 * sets the current highest bid
	 * 
	 * @param currentBid
	 *            the new highest bid
	 */
	public void setCurrentBid(Bid currentBid) {
		this.currentBid = currentBid;
	}

	/**
	 * adds a bid to the artwork, also reducing the number of bids avaliable
	 * 
	 * @param currentBid
	 */
	public void addBid(Bid currentBid) {
		this.currentBid = currentBid;
		noOfBids--;

	}

	/**
	 * gets the id of the artwork
	 * 
	 * @return
	 */
	public int getId() {
		return id;
	}

	/**
	 * returns true if there is another bid avaliable, the no of bids is not
	 * less than 0
	 * 
	 * @return
	 */
	public boolean bidAvaliable() {
		if (noOfBids <= 0) {
			return false;
		}
		return true;
	}

	/**
	 * returns the type of artwork, either painting or sculpture
	 * 
	 * @return
	 */
	public String getType() {
		return type;
	}

	/**
	 * returns the price of the artwork, either the reserve or the bid, if there
	 * is any on it
	 * 
	 * @return
	 */
	public int getPrice() {
		if (currentBid != null) {
			return currentBid.getPrice();
		}
		return reservePrice;
	}

	/**
	 * sets the start time of the artwork
	 * 
	 * @param startTime
	 */
	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	/**
	 * prints out the title when the object is printed out as a string
	 */
	public String toString() {
		return title;
	}

}
