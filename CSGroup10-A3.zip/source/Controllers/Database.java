package Controllers;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import javafx.scene.image.Image;

/**
 * A class to store refrences to the management of data classes and provide
 * operations of storing and manipulating data to the rest of the program
 * 
 * @author Ziggy, Alex
 */
public class Database {
	// stores references to the management classes and profile that are used by
	// the guis
	private static BidManagement bidManagement = new BidManagement();
	private static ArtworkManagement artworkManagement = new ArtworkManagement();
	private static ProfileManagement profileManagement = new ProfileManagement();
	private static Profile currentProfile;

	public Database() {
	}

	/**
	 * returns the current profile that is logged on
	 * 
	 * @return currentprofile, the current profile logged on
	 */
	public static Profile getProfile() {
		return currentProfile;
	}

	/**
	 * sets the profile currently logged on
	 * 
	 * @param profile
	 */
	public static void setProfile(Profile profile) {
		currentProfile = profile;
	}

	/**
	 * This returns the bidmanagement, so the classes can manipulate the bids
	 * 
	 * @return bidmanagement
	 */
	public static BidManagement manageBids() {
		return bidManagement;
	}

	/**
	 * This returns the artworkmanagement, so the classes can manipulate the
	 * artworks
	 * 
	 * @return artworkmanagement
	 */
	public static ArtworkManagement manageArtwork() {
		return artworkManagement;
	}

	/**
	 * This returns the profile management, so the classes can manipulate the
	 * profiles
	 * 
	 * @return profilemanagement
	 */
	public static ProfileManagement manageProfiles() {
		return profileManagement;
	}

	/**
	 * a method to return an arraylist of bufferedimages given an arraylist of
	 * filepaths to these image(s)
	 * 
	 * @param filePaths
	 *            an arraylist containing filepaths to images
	 * @return an arraylist of bufferedimage objects
	 */
	public static ArrayList<Image> convertArrayListToImage(ArrayList<String> filePaths) {
		ArrayList<Image> temp = new ArrayList<Image>();
		for (int i = 0; i < filePaths.size(); i++) {
			temp.add(convertPathToImage(filePaths.get(i)));
		}
		return temp;
	}

	/**
	 * converts a filepath defined to an image
	 * 
	 * @param filePath
	 *            the filepath, as a string to the image
	 * @return the image, in a bufferedimage object
	 */
	public static Image convertPathToImage(String filePath) {
		Image image = new Image(filePath, true);
		return image;
	}

	/**
	 * saves every object, one at a time, after ordering them according to ids,
	 * desc.
	 */
	public static void save() {
		// save the profiles
		profileManagement.save();
		artworkManagement.save();
		bidManagement.save();

	}

	/**
	 * loads all of the data from the storage file, and loads it into runtime
	 * memory
	 */
	public static void load() {
		artworkManagement.load();
		profileManagement.load();
		bidManagement.load();

		profileManagement.loadReferences(artworkManagement);
		artworkManagement.loadReferences(bidManagement, profileManagement);
		bidManagement.loadReferences(artworkManagement, profileManagement);
	}
}
