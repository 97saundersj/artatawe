package Controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class BuildInAvatar {

	@FXML
	private ImageView default1, default2, default3, default4, default5, default6;

	@FXML
	private Button cancelBtn;

	private Profile user;

	public void setUser(Profile user) {
		this.user = user;
	}

	/**
	 * This is the action for Cancel button, user can shut down the build in
	 * avatar page by this button
	 * 
	 * @throws Exception
	 */
	@FXML
	public void cancelAndShutDown() throws Exception {
		// This is the action for Cancel button, user can shut down the build in
		// avatar page by this button
		Stage currentStage = (Stage) cancelBtn.getScene().getWindow();
		currentStage.close();
	}

	/**
	 * checks on which picture the mouse is clicked
	 * 
	 * @param e
	 *            check for mouse button press
	 * @throws Exception
	 */
	@FXML
	public void imageSelectMouseClick1(MouseEvent e) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
		Stage stage = new Stage();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		user.setProfilePicPath("Images/default1.png");
		stage.show();
		Stage currentStage = (Stage) cancelBtn.getScene().getWindow();
		currentStage.close();
	}

	/**
	 * checks on which picture the mouse is clicked
	 * 
	 * @param e
	 *            check for mouse button press
	 * @throws Exception
	 */
	@FXML
	public void imageSelectMouseClick2(MouseEvent e) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
		Stage stage = new Stage();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		user.setProfilePicPath("Images/default2.png");
		stage.show();
		Stage currentStage = (Stage) cancelBtn.getScene().getWindow();
		currentStage.close();
	}

	/**
	 * checks on which picture the mouse is clicked
	 * 
	 * @param e
	 *            check for mouse button press
	 * @throws Exception
	 */
	@FXML
	public void imageSelectMouseClick3(MouseEvent e) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
		Stage stage = new Stage();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		user.setProfilePicPath("Images/default3.png");
		stage.show();
		Stage currentStage = (Stage) cancelBtn.getScene().getWindow();
		currentStage.close();
	}

	/**
	 * checks on which picture the mouse is clicked
	 * 
	 * @param e
	 *            check for mouse button press
	 * @throws Exception
	 */
	@FXML
	public void imageSelectMouseClick4(MouseEvent e) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
		Stage stage = new Stage();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		user.setProfilePicPath("Images/default4.png");
		stage.show();
		Stage currentStage = (Stage) cancelBtn.getScene().getWindow();
		currentStage.close();
	}

	/**
	 * checks on which picture the mouse is clicked
	 * 
	 * @param e
	 *            check for mouse button press
	 * @throws Exception
	 */
	@FXML
	public void imageSelectMouseClick5(MouseEvent e) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
		Stage stage = new Stage();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		user.setProfilePicPath("Images/default5.png");
		stage.show();
		Stage currentStage = (Stage) cancelBtn.getScene().getWindow();
		currentStage.close();
	}

	/**
	 * checks on which picture the mouse is clicked
	 * 
	 * @param e
	 *            check for mouse button press
	 * @throws Exception
	 */
	public void imageSelectMouseClick6(MouseEvent e) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
		Stage stage = new Stage();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		user.setProfilePicPath("Images/default6.png");
		stage.show();
		Stage currentStage = (Stage) cancelBtn.getScene().getWindow();
		currentStage.close();
	}
}
