package Controllers;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

import javax.imageio.ImageIO;

/**
 * A class to store and manipulate the storage of artworks
 * 
 * @author Dan,Alex
 */
public class ArtworkManagement {
	private static final String fileName = "src/Data/Artwork.txt";
	private ArrayList<Artwork> artworks;
	private ArrayList<Integer> currentBids = new ArrayList<Integer>();
	private ArrayList<String> creators = new ArrayList<String>();

	/**
	 * Creates a new ArtworkManagement object There should only be one instance
	 * of this class, in database
	 */
	ArtworkManagement() {
		artworks = new ArrayList<Artwork>();
	}

	/**
	 * gets an artwork by id
	 * 
	 * @param id,
	 *            the id of the artwork
	 */
	public Artwork getArtworkByID(int id) {
		for (int i = 0; i < artworks.size(); i++) {
			if (artworks.get(i).getId() == id) {
				return artworks.get(i);
			}
		}
		return null;
	}

	/**
	 * returns all of the artworks currently in the system
	 * 
	 * @return artworks array, an array of every artwork object registered
	 */
	public ArrayList<Artwork> getAllArtworks() {
		return artworks;
	}

	/**
	 * Adds a new artwork to the system
	 * 
	 * @param title
	 *            the title of the painting
	 * @param description
	 *            description of the painting
	 * @param mainPhoto
	 *            an image of the painting
	 * @param creator
	 *            the profile that has put the painting up for auction
	 * @param yearOfCreation
	 *            LocalDateTime when the painting was added to the system
	 * @param reservePrice
	 *            the reserve price under which no successful bid can be made
	 * @param noOfBids
	 *            maximum amount of permitted bids before the painting is sold
	 * @param width
	 *            the width of the painting
	 * @param height
	 *            the height of the painting
	 */
	public void addPainting(String title, String description, String mainPhoto, Profile creator, int yearOfCreation,
			int reservePrice, int noOfBids, int width, int height) {
		Artwork painting = new Artwork(title, description, mainPhoto, creator, yearOfCreation, reservePrice, noOfBids,
				width, height, LocalDateTime.now());
		artworks.add(painting);
	}

	/**
	 * searches only the paintings
	 * 
	 * @param search
	 * @return arraylist<artwork> of paintings
	 */
	public ArrayList<Artwork> searchPaintings(String search) {
		ArrayList<Artwork> temp = new ArrayList<Artwork>();
		for (int i = 0; i < artworks.size(); i++) {
			if (artworks.get(i).getTitle().equals(search) && artworks.get(i).getType().equals("Artwork")) {
				temp.add(artworks.get(i));
			}
		}
		return (temp);
	}

	/**
	 * searches only the sculptures
	 * 
	 * @param search
	 * @return arraylist<artwork> of sculptures
	 */
	public ArrayList<Artwork> searchSculptures(String search) {
		ArrayList<Artwork> temp = new ArrayList<Artwork>();
		for (int i = 0; i < artworks.size(); i++) {
			if (artworks.get(i).getTitle().equals(search) && artworks.get(i).getType().equals("Sculpture")) {
				temp.add(artworks.get(i));
			}
		}
		return (temp);
	}

	/**
	 * searches only the favourites of a given user
	 * 
	 * @param search
	 * @param profile
	 *            the profile of the user to be searched
	 * @return
	 */
	public ArrayList<Artwork> searchFavourites(String search, Profile profile) {
		ArrayList<Artwork> temp = new ArrayList<Artwork>();
		for (int i = 0; i < artworks.size(); i++) {
			if (artworks.get(i).getTitle().equals(search)) {
				for (int a = 0; a < profile.getFavourites().size(); a++) {
					if (profile.getFavourites().get(a).getUserName().equals(artworks.get(i).getCreator().getUserName()))
						temp.add(artworks.get(i));
				}
			}
		}

		return (temp);
	}

	/**
	 * Adds a new sculpture to the system
	 * 
	 * @param title
	 *            the title of the sculpture
	 * @param description
	 *            description of the sculpture
	 * @param mainPhoto
	 *            an image of the sculpture
	 * @param creator
	 *            the profile that has put the sculpture up for auction
	 * @param yearOfCreation
	 *            LocalDateTime when the sculpture was added to the system
	 * @param reservePrice
	 *            the reserve price under which no successful bid can be made
	 * @param noOfBids
	 *            maximum amount of permitted bids before the sculpture is sold
	 * @param width
	 *            the width of the sculpture
	 * @param height
	 *            the height of the sculpture
	 * @param material
	 *            the material the sculpture is made from
	 */
	public void addSculpture(String title, String description, String mainPhoto, Profile creator, int yearOfCreation,
			int reservePrice, int noOfBids, int width, int height, int depth, String material) {
		Sculpture sculpture = new Sculpture(title, description, mainPhoto, creator, yearOfCreation, reservePrice,
				noOfBids, width, height, LocalDateTime.now(), depth, material);
		artworks.add(sculpture);
	}

	/**
	 * returns all of the artworks that a profile has put on to the system
	 * 
	 * @param profile
	 *            the profile whose artworks are to be found
	 * @return an artwork array of all of the artworks that the profile has
	 *         listed
	 */
	public ArrayList<Artwork> getArtworkByProfile(Profile profile) {
		ArrayList<Artwork> temp = new ArrayList<Artwork>();
		for (int i = 0; i < artworks.size(); i++) {
			if (artworks.get(i).getCreator() == profile) {
				temp.add(artworks.get(i));
			}
		}
		return (temp);
	}

	/**
	 * returns all of the artworks that have this requested title
	 * 
	 * @param title
	 *            the title of the artworks to be found
	 * @return an artwork array of all of the artworks that have those
	 *         characters in the title
	 */
	public ArrayList<Artwork> getArtworkByTitle(String title) {
		ArrayList<Artwork> temp = new ArrayList<Artwork>();
		for (int i = 0; i < artworks.size(); i++) {
			if (artworks.get(i).getTitle().equals(title)) {
				temp.add(artworks.get(i));
			}
		}
		return (temp);
	}

	/**
	 * saves the contents of the data storage onto a txt file
	 */
	public void save() {
		File file = new File(fileName);
		try {
			FileWriter fileWriter = new FileWriter(file);
			for (int i = 0; i < artworks.size(); i++) {
				String line = "";
				line += (artworks.get(i).getTitle()) + ",";
				line += (artworks.get(i).getCreator().getUserName()) + ",";
				line += (artworks.get(i).getNoOfBids()) + ",";
				line += (artworks.get(i).getYearOfCreation()) + ",";
				line += (artworks.get(i).getReservePrice()) + ",";
				line += (artworks.get(i).getWidth()) + ",";
				line += (artworks.get(i).getHeight()) + ",";
				line += (artworks.get(i).getStartTime()) + ",";
				if (artworks.get(i).getCurrentBid() != null) {
					line += (artworks.get(i).getCurrentBid().getId()) + ",";
				} else {
					line += ",";
				}
				line += (artworks.get(i).getDescription()) + ",";
				line += (artworks.get(i).getType()) + ",";
				line += (artworks.get(i).getMainPhoto() + ",");
				if (artworks.get(i).getType().equals("Sculpture")) {
					line += (((Sculpture) artworks.get(i)).getMaterial()) + ",";
					line += (((Sculpture) artworks.get(i)).getDepth()) + ",";
				}
				for (int a = 0; a < artworks.get(i).getAllPhotos().size(); a++) {
					line += artworks.get(i).getAllPhotos().get(a) + ",";
				}
				fileWriter.write(line);
				fileWriter.write("\n");
			}
			fileWriter.close();
		} catch (Exception e) {
			// file io error
			e.printStackTrace();
		}
	}

	/**
	 * loads every profile to the text file listed, without references
	 */
	public void load() {
		File file = new File(fileName);
		try {
			Scanner fileReader = new Scanner(file);
			while (fileReader.hasNext()) {
				String line = fileReader.nextLine();
				String[] data = line.split(",");
				String title = data[0];
				String username = data[1];
				creators.add(username);
				String noOfBids = data[2];
				String yearOfCreation = data[3];
				String reservePrice = data[4];
				String width = data[5];
				String height = data[6];
				LocalDateTime bidStart = LocalDateTime.parse(data[7]);
				String bidID = data[8];
				if (!bidID.equals("")) {
					currentBids.add(Integer.parseInt(bidID));
				} else {
					currentBids.add(-1);
				}
				String description = data[9];
				String type = data[10];
				String material = null;
				String depth = null;
				String mainPhoto = data[11];
				ArrayList<String> imagePaths = new ArrayList<String>();
				if (type.equals("Sculpture")) {
					material = data[12];
					depth = data[13];
					for (int i = 14; i < data.length; i++) {
						imagePaths.add(data[i]);
					}
				} else {
					for (int i = 12; i < data.length; i++) {
						imagePaths.add(data[i]);
					}
				}
				if (type.equals("Artwork")) {
					artworks.add(new Artwork(title, description, mainPhoto, null, Integer.parseInt(yearOfCreation),
							Integer.parseInt(reservePrice), Integer.parseInt(noOfBids), Integer.parseInt(width),
							Integer.parseInt(height), bidStart));

				} else {
					artworks.add(new Sculpture(title, description, mainPhoto, null, Integer.parseInt(yearOfCreation),
							Integer.parseInt(reservePrice), Integer.parseInt(noOfBids), Integer.parseInt(width),
							Integer.parseInt(height), bidStart, Integer.parseInt(depth), material));
				}
				for (int i = 0; i < imagePaths.size(); i++) {
					artworks.get(artworks.size() - 1).addImageToArrayList(imagePaths.get(i));
				}

			}
			fileReader.close();
		} catch (Exception e) {
			// file io error
			e.printStackTrace();
		}

	}

	/**
	 * loads the references of the artworks
	 * 
	 * @param bidManagement
	 * @param profileManagement
	 */
	public void loadReferences(BidManagement bidManagement, ProfileManagement profileManagement) {
		for (int i = 0; i < artworks.size(); i++) {
			if (currentBids.get(i) != -1) {
				artworks.get(i).setCurrentBid(bidManagement.searchByID(currentBids.get(i)));
			}
			artworks.get(i).setCreator(profileManagement.searchProfile(creators.get(i)));
		}
	}
}
