package Controllers;

import java.awt.Image;
import java.time.LocalDateTime;

/**
 * a class that stores a sculpture, an exention of artworks, where artworks are
 * paintings
 * 
 * @author Morco
 */
public class Sculpture extends Artwork {
	private int depth;
	private String material;

	/**
	 * constructs a new sculpture
	 * 
	 * @param title
	 * @param description
	 * @param mainPhoto
	 *            the path to the main photo for hte sculpture
	 * @param creator
	 * @param yearOfCreation
	 * @param reservePrice
	 * @param noOfBids
	 *            the maximum number of bids
	 * @param width
	 * @param height
	 * @param startTime
	 * @param depth
	 *            the depth of the sculpture
	 * @param material
	 *            the material
	 */
	public Sculpture(String title, String description, String mainPhoto, Profile creator, int yearOfCreation,
			int reservePrice, int noOfBids, int width, int height, LocalDateTime startTime, int depth,
			String material) {
		super(title, description, mainPhoto, creator, yearOfCreation, reservePrice, noOfBids, width, height, startTime);
		this.depth = depth;
		this.material = material;
		super.type = "Sculpture";
	}

	// setters and getters
	public int getDepth() {
		return depth;
	}

	public void setDepth(int depth) {
		this.depth = depth;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

}
