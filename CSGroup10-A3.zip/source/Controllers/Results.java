package Controllers;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * The result page for showing the result of searched data
 * 
 * @Author Marco
 */
public class Results {

	@FXML
	private Label warningMsg;

	@FXML
	private TextField searchBar;

	@FXML
	private Button searchBtn, backToProfileBtn, logoutBtn;

	@FXML
	private CheckBox sculptureFilter, paintingFilter, favouriteFilter;

	@FXML
	private ListView artworksList;

	@FXML
	private Label keywordsText;

	@FXML
	private Button goBackBtn, homeBtn;

	/**
	 * this is the action of switching back to home page by pressing the HOME
	 * button
	 */
	@FXML
	public void switchBackHome() throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("../gui/home.fxml"));
		Stage currentStage = (Stage) homeBtn.getScene().getWindow();
		currentStage.close();
		Stage stage = new Stage();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * this is the action of going back to previous page the searching screen by
	 * the GO BACK button
	 * 
	 * @throws Exception
	 */
	@FXML
	public void goBackPreviousPage() throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("../gui/home.fxml"));
		Stage currentStage = (Stage) goBackBtn.getScene().getWindow();
		currentStage.close();
		Stage stage = new Stage();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * searches for artwork, using different filters
	 */
	@FXML
	public void search() {
		ArrayList<Artwork> searchResults = null;
		if (paintingFilter.isSelected()) {
			searchResults = Database.manageArtwork().searchPaintings(searchBar.getText());
		} else if (sculptureFilter.isSelected()) {
			searchResults = Database.manageArtwork().searchSculptures(searchBar.getText());
		} else if (favouriteFilter.isSelected()) {
			searchResults = Database.manageArtwork().searchFavourites(searchBar.getText(), Database.getProfile());
		} else {
			searchResults = Database.manageArtwork().getArtworkByTitle(searchBar.getText());
		}

		ArrayList<String> stringResults = new ArrayList<String>();
		for (int i = 0; i < searchResults.size(); i++) {
			stringResults.add("Title: " + searchResults.get(i).getTitle() + ": Description: "
					+ searchResults.get(i).getDescription());
		}
		artworksList.getItems().clear();
		artworksList.getItems().addAll(stringResults);
	}

	/**
	 * changes the screen to that artwork the user clicked
	 * 
	 * @param click
	 * @throws Exception
	 */
	public void artworkViewMouseClick(MouseEvent click) throws Exception {
		// this is the mouse click event for user to double the list item to get
		// in to viewing page
		if (click.getClickCount() == 2) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("../gui/viewArt.fxml"));

			Stage stage = new Stage();
			stage.setScene(new Scene((Pane) loader.load()));
			ArtworkView controller = loader.<ArtworkView>getController();
			String string = artworksList.getSelectionModel().getSelectedItem().toString().split(":")[1];
			controller.setArtwork(Database.manageArtwork().getArtworkByTitle(string).get(0));

			stage.show();
		}
	}

	/**
	 * this is the action of logout and back to login screen by LOGOUT button
	 * 
	 * @throws Exception
	 */
	@FXML
	public void logout() throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
		Stage currentStage = (Stage) logoutBtn.getScene().getWindow();
		currentStage.close();
		Stage stage = new Stage();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * This is the button action for switching back to the profile page
	 * 
	 * @param event
	 * @throws Exception
	 */
	@FXML
	public void toProfile(ActionEvent event) throws Exception {
		Stage currentStage = (Stage) backToProfileBtn.getScene().getWindow();
		currentStage.close();
		Parent page = FXMLLoader.load(getClass().getResource("../gui/home.fxml"));
		Stage stage = new Stage();
		Scene scene = new Scene(page);
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * formats the information
	 */
	@FXML
	private void initialize() {
		ArrayList<Artwork> searchResults = Database.manageArtwork().getAllArtworks();
		ArrayList<String> stringResults = new ArrayList<String>();
		for (int i = 0; i < searchResults.size(); i++) {
			stringResults.add("Title:" + searchResults.get(i).getTitle() + ": Description: "
					+ searchResults.get(i).getDescription());
		}
		artworksList.getItems().clear();
		artworksList.getItems().addAll(stringResults);

	}

}
