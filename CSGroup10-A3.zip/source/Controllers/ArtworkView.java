package Controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * This is the page for viewing an artwork with detail
 * 
 * @Author Marco
 */
public class ArtworkView {
	private Artwork artwork;

	@FXML
	private ImageView artworkImage;

	@FXML
	private Button placeBidBtn, closeBtn, addFavUserBtn, addFavArtBtn;

	@FXML
	private Label title, creator, price, type, noOfBid, width, height, depth, material, time;

	@FXML
	private TextField bidValue;

	@FXML
	private TextArea description;

	/**
	 * This is the action for Close button, user can close current window by
	 * this action
	 * 
	 * @throws Exception
	 */
	@FXML
	public void closeWindow() throws Exception {
		// This is the action for Close button, user can close current window by
		// this action
		Stage currentStage = (Stage) closeBtn.getScene().getWindow();
		currentStage.close();
	}

	/**
	 * sets the artwork that the gui is viewing, and displaying data of to the
	 * artwork defined
	 * 
	 * @param art
	 *            the artwork to view
	 */
	public void setArtwork(Artwork art) {
		this.artwork = art;
		title.setText(art.getTitle());
		description.setText(art.getDescription());
		creator.setText(art.getCreator().getUserName());
		price.setText(art.getPrice() + "");
		type.setText(art.getType());
		noOfBid.setText(art.getNoOfBids() + "");
		width.setText(art.getWidth() + "");
		height.setText(art.getHeight() + "");
		if (art.getType().equals("Sculpture")) {
			depth.setText(((Sculpture) art).getDepth() + "");
			material.setText(((Sculpture) art).getMaterial());
		}
		artworkImage.setImage(Database.convertPathToImage(artwork.getMainPhoto()));
		time.setText(Database.manageArtwork().getArtworkByTitle(art.getTitle()).get(0).getStartTime().getMonth() + " "
				+ Database.manageArtwork().getArtworkByTitle(art.getTitle()).get(0).getStartTime().getDayOfMonth());
	}

	/**
	 * moves the scene to the Artwork creator's (limited) profile page
	 * 
	 * @throws Exception
	 */
	public void goToCreator() throws Exception {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../gui/viewUser.fxml"));
		Stage stage = new Stage();
		stage.setScene(new Scene((Pane) loader.load()));
		ViewUser controller = loader.<ViewUser>getController();
		controller.setUser(artwork.getCreator());
		stage.show();
	}

	/**
	 * adds another profile to that user's list of favorites
	 * 
	 * @throws Exception
	 */
	@FXML
	public void addFavourite() throws Exception {
		Database.manageProfiles().addFavourite(Database.getProfile(), artwork.getCreator());
	}

	/**
	 * places bid on an artwork
	 * 
	 * @throws Exception
	 */
	@FXML
	public void placeBid() throws Exception {
		Database.manageBids().addBid(Database.getProfile(), artwork, Integer.parseInt(bidValue.getText()));
	}

	@FXML
	private void initialize() {

	}
}
