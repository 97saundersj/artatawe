/**
 * Class to start the program, and load the inital call from the database
 * @author Ziggy
 */
package Controllers;

import javafx.application.Application;

public class Main {
	/**
	 * this constructs the database, the subsystem for use in the rest of the
	 * code, from the txt files in data
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Database.load();
		Application.launch(ArtataweMain.class, args);
	}
}
