Step 1. Put the Artatawe Package into IDE
Step 2. Open the Controllers package
Step 3. Run the ArtataweMain.java
Step 4. Compile it
Step 5. There's already a user named admin (for testing purposes). You can either log in as him or register a new profile
Step 6. While registering, you can choose to either draw your own avatar, or pick a pre-defined one
Step 7. Once on the home screen, you can choose to either view your profile (along with any relevant information), add a new artwork, or search for artworks
Step 8. On the User page, you can double click on a favorite's name to view their (limited) profile
Step 9. On the Add an artwork page, you can either choose to enter an artwork or a sculpture into the system (material and depth don't matter for artworks)
Step 10. The search for artworks will initially display all artworks/sculptures in history, a user can search for a title, (having the choice to use the filters or not) which will return 
an array of artworks/sculptures with that title. The user can click on any artwork/sculpture to display a more detailed page about that piece.
WHile on that page, the user can choose to add that seller as a favorite.   


Notes: Some IDEs dont refresh after creating a new profile/image/artwork so it needs to be manually refreshed
	Artwork = painting 
	Sometimes artworks are saved with a tab, which will break the searching system ( no idea why)