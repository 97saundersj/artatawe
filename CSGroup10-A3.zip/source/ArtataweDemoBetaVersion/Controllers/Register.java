package Controllers;

import javafx.scene.control.Label;
import sample.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * The Register Gui, for user's registration
 * @Author Marco
 * TODO Need to register username to database
 */
public class Register {
    Database database;

    public void setDatabase(Database database) {
        this.database = database;
    }

    @FXML
    private Label warningMsg;

    @FXML
    private TextField registerId;

    @FXML
    private Button closeBtn, submitBtn;

    @FXML
    public void closeCurrentPage()throws Exception{
        //the action of go back button, which for linking to the login interface
        Stage currentStage = (Stage) closeBtn.getScene().getWindow();
        currentStage.close();
    }

   @FXML
    public void submitUserName()throws Exception{
        //the action method of the submit button, which submit the new registered username to the database
       //TODO need to check the database if the username was registered
        if(!registerId.getText().isEmpty()) {
            warningMsg.setText("If it is shown, then it works");
        }else if(registerId.getText().isEmpty()){
            warningMsg.setText("User name cannot be empty");
        }else{
            warningMsg.setText("This user name has been registered");
        }
    }
    public void initialize() {

    }
}
