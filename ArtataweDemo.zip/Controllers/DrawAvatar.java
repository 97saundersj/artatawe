package Controllers;

/**
 * Created by Morco on 12/6/2017.
 */
public class DrawAvatar {
}
