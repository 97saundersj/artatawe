package Controllers;

import Artatawe.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.awt.*;

/**
 * The Register Gui, for user's registration
 * @Author Marco
 * TODO Need to register username to database
 */
public class Register {
    Database database;

    public void setDatabase(Database database) {
        this.database = database;
    }

    @FXML
    private TextField registerId;

    @FXML
    private Button goBackBtn;

    @FXML
    public void goBackPreviousPage(ActionEvent event)throws Exception{
        //the action of go back button, which for linking to the login interface
        Stage currentStage = (Stage) goBackBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

   /* @FXML
    public void submitUserName(ActionEvent event)throws Exception{
        //the action method of the submit button, which submit the new registered username to the database
        if() {
            Stage currentStage = (Stage) goBackBtn.getScene().getWindow();
            currentStage.close();
            Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }else{
        Parent root = FXMLLoader.load(getClass().getResource("../gui/(POPUPWINDOWS).fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            tage.setScene(scene);
           stage.show();
        }
    }*/

    public void initialize() {

    }
}
