package Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;


public class SearchController {
    String searchTest =  "test";

    @FXML
    private Label warningMsg;

    @FXML
    private TextField searchBar;

    @FXML
    private Button searchBtn, logoutBtn, backToProfileBtn;

    @FXML
    private CheckBox sculptureFilter;

    @FXML
    private CheckBox paintingFilter;

    @FXML
    public void filterSearch(ActionEvent event)throws Exception {
        if (searchBar.getText().equals(searchTest)) {
            if (sculptureFilter.isSelected() && paintingFilter.isIndeterminate()) {
                //filter of searching sculpture only
            } else if (paintingFilter.isSelected() && sculptureFilter.isIndeterminate()) {
                //filter of searching painting only
            } else {
                //filter of  searching both
            }
        }else{
            warningMsg.setText("Invalid Keywords" );
        }
    }

    @FXML
    public void logout(ActionEvent event)throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
        Stage currentStage = (Stage) logoutBtn.getScene().getWindow();
        currentStage.close();
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void toProfile(ActionEvent event)throws Exception{
        Parent page = FXMLLoader.load(getClass().getResource("../gui/profile.fxml"));
        Stage currentStage = (Stage) backToProfileBtn.getScene().getWindow();
        currentStage.close();
        Stage stage = new Stage();
        Scene scene = new Scene(page);
        stage.setScene(scene);
        stage.show();
    }

    private void initialize() {

    }

}
