package Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * This is the home page of the ARTATAWE, it allows user to access to different page by serveral buttons
 * @Author Marco
 * //TODO set current local time
 */

public class Home {

    @FXML
    private Button logoutBtn, searchBtn, viewProfileBtn, addArtworkBtn;

    public void logout(ActionEvent event)throws Exception{
        //this is the action of logout and back to login page by LOGOUT button
        Stage currentStage = (Stage) logoutBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void search(ActionEvent event)throws Exception{
        //this is the action of  switching to searching screen by SEARCH FOR BID button
        Stage currentStage = (Stage) searchBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/search.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


    @FXML
    public void viewProfile(ActionEvent event)throws Exception{
        //this is the action of switching to profile page by VIEW YOUR PROFILE button
        Stage currentStage = (Stage) viewProfileBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/profile.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void addArtwork(ActionEvent event)throws Exception{
        //this is the action of switching to add artwork page by ADD NEW ARTWORK button
        Stage currentStage = (Stage) addArtworkBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/uploadArt.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
