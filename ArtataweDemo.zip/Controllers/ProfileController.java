package Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;


public class ProfileController {

    @FXML
    private Button logoutBtn, searchBtn;

    public void logout(ActionEvent event)throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
        Stage currentStage = (Stage) logoutBtn.getScene().getWindow();
        currentStage.close();
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void search(ActionEvent event)throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("../gui/search.fxml"));
        Stage currentStage = (Stage) searchBtn.getScene().getWindow();
        currentStage.close();
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

}
