package Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;


/**
 * This is the page for viewing an artwork with detail
 * @Author Marco
 * //TODO placebid, add favourite user and artworks , image not yet displayed, need to get information from database
 * //TODO it should be two way for linking this page, one is from result page, one is from favourite artwork on the list in Profile gui
 */
public class ArtworkView {

    @FXML
    private ImageView artworkImage;

    @FXML
    private Button placeBidBtn, homeBtn, addFavUserBtn, addFavArtBtn;

    @FXML
    public void switchBackHome(ActionEvent event)throws Exception{
        //This is the action for logout button, user can logout by this button and go back to the login page
        Stage currentStage = (Stage) homeBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/home.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void initialize(){

    }
}
