package Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;



/**
 *The Profile page of user, showing different information
 *@Author Marco
 * TODO the upload system is now on, but not yet link to the imageView part
 * TODO need to be able to get user's information and  store in this page
 * TODO need to get favourite artwork and users shown in the two list table, and artwork uploaded need to be shown in the list of artworks
 */
public class ProfileGui {

    @FXML
    private ImageView avatar;

    @FXML
    private Button goBackBtn, logoutBtn;

    @FXML
    private ListView artWork, favArtWork, favUser;

    @FXML
    public void logout(ActionEvent event)throws Exception{
        //This is the action for logout button, user can logout by this button and go back to the login page
        Stage currentStage = (Stage) logoutBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void goBackPreviousPage(ActionEvent event)throws Exception{
        //This is the action for logout button, user can logout by this button and go back to the login page
        Stage currentStage = (Stage) goBackBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/home.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void uploadAvatar(ActionEvent event)throws Exception{
        //This is the action for browsing the image from local system
        Stage stage = new Stage();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Image File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Images", "*.*"),
                new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("PNG", "*.png")
        );
        fileChooser.showOpenDialog(stage);
    }

    @FXML
    private void initialize() {

    }

}
