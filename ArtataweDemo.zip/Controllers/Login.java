package Controllers;

import Artatawe.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * The Controller of Login Gui
 * @Author Marco
 * TODO need to add method to get username from database which registered from register gui
 */
public class Login {
    String acc = "admin";
    Register register;
    Database database;


    public void setDatabase(Database database) {
        this.database = database;
    }

    //The reference of userName will be injected by the FXML Loader
    @FXML
    private TextField user;

    @FXML
    private Label warningMsg;

    @FXML
    private Button loginBtn;

    @FXML
    private Button registerBtn;

    @FXML
    public void handleButtonActionSignIn(ActionEvent event)throws Exception{
        //the action of the login button, which link to the profile interface and detect if there a invalid user input from database
    if (user.getText().equals(acc)){
        Stage currentStage = (Stage) loginBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/home.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }else{
        warningMsg.setText("Invalid User name");
        }
    }

    @FXML
    public void handleButtonActionRegister(ActionEvent event)throws Exception{
        //the action of register button, which for linking to the register interface
        Stage currentStage = (Stage) registerBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/register.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void onEnter(ActionEvent ae)throws Exception{
        //the shortcut method for the login button, user can input with enter key on their keyboard
        if (user.getText().equals(acc)){
            warningMsg.setText("");
            Parent root = FXMLLoader.load(getClass().getResource("../gui/home.fxml"));
            Stage currentStage = (Stage) loginBtn.getScene().getWindow();
            currentStage.close();
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }else{
            warningMsg.setText("Invalid User name");
        }
    }

    public void initialize() {

    }


}

