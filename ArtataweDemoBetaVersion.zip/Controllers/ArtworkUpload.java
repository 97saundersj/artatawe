package Controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * The page for user to upload their artwork
 * @Author Marco
 * //TODO need to add the path to the textfield automatically when a file is chosen from local system, if impossible then delete the textfield leave the upload alone, or instead
 * //TODO see uploadArtWork() method
 */
public class ArtworkUpload {
    ObservableList<String> chooseTypeList = FXCollections.observableArrayList("Painting", "Sculpture");

    @FXML
    private TextField title, price, filePath;

    @FXML
    private TextArea description;

    @FXML
    private Button goBackBtn, logoutBtn, browsArtBtn, uploadArtBtn;

    @FXML
    private ChoiceBox chooseTypeBox;

    @FXML
    public void logout() throws Exception {
        //this is the action of logout and back to login screen by LOGOUT button
        Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
        Stage currentStage = (Stage) logoutBtn.getScene().getWindow();
        currentStage.close();
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void goBackPreviousPage() throws Exception {
        //this is the action of going back to previous page the searching screen by the GO BACK button
        Parent root = FXMLLoader.load(getClass().getResource("../gui/home.fxml"));
        Stage currentStage = (Stage) goBackBtn.getScene().getWindow();
        currentStage.close();
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void browseArtWork() throws Exception {
        //this is the action of uploading an artwork by browsing the file in local system
    fileChooser();
    }

    public void fileChooser(){
        Stage stage = new Stage();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Image File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Images", "*.*"),
                new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("PNG", "*.png")
        );
        fileChooser.showOpenDialog(stage);

    }

    @FXML
    public void uploadArtWork()throws Exception{
        //this is the action for uploading an artwork through button
    if(title != null && price != null && filePath != null && description !=null){
        //TODO  detect title as string, price as double or INT(?), filePath = string, and after pressing them need to switch back to home page
        if( chooseTypeBox.getValue().equals("Painting")){
            //TODO if  painting was chosen, store to painting
        }else{
            //TODO if sculpture was chosen, store to sculpture
        }
    }else{

        }
    }


    @FXML
     private void initialize(){
        //this is for setting option for the choicebox
        chooseTypeBox.setValue("Painting");
        chooseTypeBox.setItems(chooseTypeList);
    }
}
