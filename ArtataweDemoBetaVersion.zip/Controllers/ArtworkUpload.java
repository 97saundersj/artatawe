package Controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import sample.Database;

import java.io.File;

/**
 * The page for user to upload their artwork
 * @Author Marco
 * //TODO need to add the path to the textfield automatically when a file is chosen from local system, if impossible then delete the textfield leave the upload alone, or instead
 * //TODO see uploadArtWork() method
 */
public class ArtworkUpload {
    Database database;
    public void setDatabase(Database database) {
        this.database = database;
    }
    ObservableList<String> chooseTypeList = FXCollections.observableArrayList("Painting", "Sculpture");

    FileChooser fileChooser = new FileChooser();

    @FXML
    private Label warningMsg;

    @FXML
    private TextField title, price, filePath;

    @FXML
    private TextArea description;

    @FXML
    private Button goBackBtn, logoutBtn, browsArtBtn, uploadArtBtn;

    @FXML
    private ChoiceBox chooseTypeBox;

    @FXML
    public void logout() throws Exception {
        //this is the action of logout and back to login screen by LOGOUT button
        Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
        Stage currentStage = (Stage) logoutBtn.getScene().getWindow();
        currentStage.close();
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void goBackPreviousPage() throws Exception {
        //this is the action of going back to previous page the searching screen by the GO BACK button
        Parent root = FXMLLoader.load(getClass().getResource("../gui/home.fxml"));
        Stage currentStage = (Stage) goBackBtn.getScene().getWindow();
        currentStage.close();
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void browseImage() throws Exception{
        //this is the action of uploading an artwork by browsing the file in local system
        Stage stage = new Stage();
        fileChooser.setTitle("Open Image File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Images", "*.*"),
                new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("PNG", "*.png")
        );
       File file = fileChooser.showOpenDialog(stage);
    if(file != null){
        String filePathString = file.toString();

        filePath.setText(filePathString);
    }else{
        filePath.setText(null);
        }
    }

    @FXML
    public void uploadArtWork()throws Exception{
        //this is the action for uploading an artwork through button
    if(!title.getText().isEmpty() && !price.getText().isEmpty() && !filePath.getText().isEmpty() && !description.getText().isEmpty()){
        //TODO  detect title as string, price as double or INT(?), filePath = string, and after pressing them need to switch back to home page
        try{
            double value = Double.parseDouble(price.getText());
            double priceValue = value;
            price.setText(String.valueOf(priceValue));
        }
        catch (Exception e){
            System.out.println("price should be number!!!");
            warningMsg.setText("Reserve price need to be a number.");
            }try {
            File file = fileChooser.getInitialDirectory();
            filePath.getText().equals(file.toString());
        }catch(Exception e) {
            warningMsg.setText("Invalid File Path");
            }if(chooseTypeBox.getValue().equals("Painting")){
                System.out.println("Painting chosen");
            }else {
                System.out.println("Sculpture chosen");
            }
    }else{
        System.out.println("something is empty!!");
        warningMsg.setText("All information are needed to be filled");
        }
    }



    @FXML
     private void initialize(){
        //this is for setting option for the choicebox
        chooseTypeBox.setValue("Painting");
        chooseTypeBox.setItems(chooseTypeList);
    }
}
