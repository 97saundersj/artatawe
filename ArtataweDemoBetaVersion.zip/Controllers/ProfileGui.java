package Controllers;

import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;



/**
 *The Profile page of user, showing different information
 *@Author Marco
 * TODO the upload system is now on, but not yet link to the imageView part
 * TODO need to be able to get user's information and  store in this page
 * TODO need to get favourite artwork and users shown in the two list table, and artwork uploaded need to be shown in the list of artworks
 * TODO those listViews need to be clickable and can access to certain pages
 */
public class ProfileGui {

    @FXML
    private Label functionTester;
    private Label firstName, lastName, adress, phoneNo, userName, postCode;

    @FXML
    private ImageView avatar;

    @FXML
    private Button homeBtn, logoutBtn,drawBtn, viewArtBtn1, viewArtBtn2, viewArtBtn3, viewArtBtn4, viewUserBtn;

    @FXML
    private ListView<String> artworkList, favArtworkList, favUserList, bidWonList, bidPlacedList;

    @FXML
    public void logout(ActionEvent event)throws Exception{
        //This is the action for logout button, user can logout by this button and go back to the login page
        Stage currentStage = (Stage) logoutBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void switchBackhome(ActionEvent event)throws Exception{
        //This is the action for Home button, user can back to home page by this button
        Stage currentStage = (Stage) homeBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/home.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void viewFavArtworkAction(ActionEvent event)throws Exception {
        //This is the action for View Artwork button, user can go to the artwork page by this button
        if (favArtworkList.getSelectionModel().isSelected(1)) {
            functionTester.setText("If it is shown, then view favourite artwork action work");
            Parent root = FXMLLoader.load(getClass().getResource("../gui/viewArt.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }else{
            functionTester.setText("Select an item");

        }
    }
        @FXML
                public void viewBidWonAction(ActionEvent event)throws Exception {
            if (bidWonList.getSelectionModel().isSelected(1)) {
                functionTester.setText("If it is shown, then view bid won action work");
                Parent root = FXMLLoader.load(getClass().getResource("../gui/viewArt.fxml"));
                Stage stage = new Stage();
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            }else{
                functionTester.setText("Select an item");

            }
        }

        @FXML
    public void viewBidPlacedAction(ActionEvent event)throws Exception{
            if(bidPlacedList.getSelectionModel().isSelected(1)) {
                functionTester.setText("If it is shown, then view bid placed action work");
                Parent root = FXMLLoader.load(getClass().getResource("../gui/viewArt.fxml"));
                Stage stage = new Stage();
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            }else{
            functionTester.setText("Select an item");
            }
        }


        @FXML
    public void viewArtWorkAction() throws Exception{
            if (artworkList.getSelectionModel().isSelected(1)) {
                functionTester.setText("If it is shown, then view artwork action work");

                Parent root = FXMLLoader.load(getClass().getResource("../gui/viewArt.fxml"));
                Stage stage = new Stage();
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            }else{

            }
    }

    @FXML
    public void viewUserAction(ActionEvent event)throws Exception{
        //This is the action for View User button, user can go to the profile page of a user by this button
       if(favUserList.getSelectionModel().isSelected(1)){
           functionTester.setText("If it is shown, then view user action work");
           //Stage currentStage = (Stage) viewUserBtn.getScene().getWindow();
           //currentStage.close();
           Parent root = FXMLLoader.load(getClass().getResource("../gui/Profile.fxml"));
           Stage stage = new Stage();
           Scene scene = new Scene(root);
           stage.setScene(scene);
           stage.show();
       }else{
           functionTester.setText("Select an item");

       }
    }

    @FXML
    private void initialize() throws Exception {
        /**
         *TODO this help for getting data from profile and show on the gui page
        userName.setText(profile.getUserName);
         firstName.setText(profile.getfFirstName*/

        artworkList.getItems().addAll("Starry Night", "The Potato Eaters", "Granny", "Mama");
    }

}
