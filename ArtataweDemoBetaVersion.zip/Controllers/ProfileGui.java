package Controllers;

import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import sample.Database;


/**
 *The Profile page of user, showing different information
 *@Author Marco
 * TODO the upload system is now on, but not yet link to the imageView part
 * TODO need to be able to get user's information and  store in this page
 * TODO need to get favourite artwork and users shown in the two list table, and artwork uploaded need to be shown in the list of artworks
 * TODO those listViews need to be clickable and can access to certain pages
 */
public class ProfileGui {
    Database database;
    public void setDatabase(Database database) {
        this.database = database;
    }

    @FXML
    private Label functionTester;
    private Label firstName, lastName, adress, phoneNo, userName, postCode;

    @FXML
    private ImageView avatar;

    @FXML
    private Button homeBtn, logoutBtn;

    @FXML
    private ListView artworkList, favArtworkList, favUserList, bidWonList, bidPlacedList;


    @FXML
    public void logout()throws Exception{
        //This is the action for logout button, user can logout by this button and go back to the login page
        Stage currentStage = (Stage) logoutBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void switchBackhome()throws Exception{
        //This is the action for Home button, user can back to home page by this button
        Stage currentStage = (Stage) homeBtn.getScene().getWindow();
        currentStage.close();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/home.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


    @FXML
    public void ownArtworkViewMouseClick(MouseEvent click)throws Exception {
        //this is the mouse click event for user to double the list item to get in to viewing page
        if(click.getClickCount() == 2) {
            System.out.println("clicked on " + artworkList.getSelectionModel().getSelectedItem());
            Parent root = FXMLLoader.load(getClass().getResource("../gui/viewOwnArt.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
    }

    @FXML
    public void favUserViewMouseClick(MouseEvent click)throws Exception {
        //this is the mouse click event for user to double the list item to get in to viewing page
        if(click.getClickCount() == 2) {
            Parent root = FXMLLoader.load(getClass().getResource("../gui/viewUser.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
    }

    @FXML
    public void artworkViewMouseClick(MouseEvent click)throws Exception {
        //this is the mouse click event for user to double the list item to get in to viewing page
        if(click.getClickCount() == 2) {
            System.out.println("clicked on " + artworkList.getSelectionModel().getSelectedItem());
            Parent root = FXMLLoader.load(getClass().getResource("../gui/viewArt.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
    }
    @FXML
    private void initialize() throws Exception {
        /**
         *TODO this help for getting data from profile and show on the gui page
        userName.setText(profile.getUserName);
         firstName.setText(profile.getfFirstName*/

        artworkList.getItems().addAll("Starry Night", "The Potato Eaters", "Granny", "Mama");
        favUserList.getItems().addAll("BOBO", "JINJIN", "Kar9");
        favArtworkList.getItems().addAll("SASD","SSS","F");
        bidWonList.getItems().addAll("ASD","RE");
        bidPlacedList.getItems().addAll("C","D");
    }

}
