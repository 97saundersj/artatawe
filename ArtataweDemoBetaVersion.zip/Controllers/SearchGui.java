package Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;

/**
 * The controller of searching screen gui
 * @Author Marco
 * TODO need to be able to get data from database
 */
public class SearchGui {
    String searchTest =  "test";

    @FXML
    private Label warningMsg;

    @FXML
    private TextField searchBar;

    @FXML
    private Button searchBtn, logoutBtn, backToProfileBtn;

    @FXML
    private CheckBox sculptureFilter;

    @FXML
    private CheckBox paintingFilter;

    @FXML
    public void filterSearch(ActionEvent event)throws Exception {
        //This method contains two filter, one is sculpture and one is painting, user can search the artwork type they want by clicking the checkbox of those.
        Stage currentStage = (Stage) searchBtn.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/results.fxml"));;
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        if (searchBar.getText().equals(searchTest)) {
            warningMsg.setText("");
            if (sculptureFilter.isSelected() && !paintingFilter.isSelected()) {
                //filter of searching sculpture only
                warningMsg.setText("Test for sculpture");
                currentStage.close();
                stage.setScene(scene);
                stage.show();
            } else if (paintingFilter.isSelected() && !sculptureFilter.isSelected()) {
                //filter of searching painting only
                warningMsg.setText("Test for painting");
                currentStage.close();
                stage.setScene(scene);
                stage.show();
            } else {
                //filter of  searching both
                warningMsg.setText("Test for both");
                currentStage.close();
                stage.setScene(scene);
                stage.show();
            }
        }else{
            warningMsg.setText("Invalid Keywords" );
        }
    }

    @FXML
    public void onEnter(ActionEvent event)throws Exception {
        //This method is the same as the filterSearch method, but a shortcut version for pressing enter
        Stage currentStage = (Stage) searchBtn.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("../gui/results.fxml"));;
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        if (searchBar.getText().equals(searchTest)) {
            warningMsg.setText("");
            if (sculptureFilter.isSelected() && !paintingFilter.isSelected()) {
                //filter of searching sculpture only
                warningMsg.setText("Test for sculpture");
                currentStage.close();
                stage.setScene(scene);
                stage.show();

            } else if (paintingFilter.isSelected() && !sculptureFilter.isSelected()) {
                //filter of searching painting only
                warningMsg.setText("Test for painting");
                currentStage.close();
                stage.setScene(scene);
                stage.show();
            } else {
                //filter of  searching both
                warningMsg.setText("Test for both");
                currentStage.close();
                stage.setScene(scene);
                stage.show();
            }
        }else{
            warningMsg.setText("Invalid Keywords" );
        }
    }

    @FXML
    public void logout(ActionEvent event)throws Exception{
        //This is the action for logout button, user can logout by this button and go back to the login page

    }

    @FXML
    public void toProfile(ActionEvent event)throws Exception{
        //This is the button action for switching back to the profile page
        Stage currentStage = (Stage) backToProfileBtn.getScene().getWindow();
        currentStage.close();
        Parent page = FXMLLoader.load(getClass().getResource("../gui/home.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(page);
        stage.setScene(scene);
        stage.show();
    }


    public TextField getSearchBar(){
        return searchBar;
    }

    private void initialize() {

    }

}
