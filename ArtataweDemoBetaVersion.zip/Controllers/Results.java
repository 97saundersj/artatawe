package Controllers;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import sample.Artwork;

import java.awt.event.ActionListener;

/**
 * The result page for showing the result of searched data
 * @Author Marco
 * TODO  (TextField keywords)need to get the text from search screen's searching bar which typed by user
 * TODO (ActionListener) use this method to make artwork in the view table clickable( I dunno how so far, and I suggest the view art opened from result page be pop up window)
 */
public class Results {
    SearchGui searched = new SearchGui();

    @FXML
    private TableView resultTable;

    @FXML
    private TableColumn nameColumn, priceColumn;

    @FXML
    private Label keywordsText;

    @FXML
    private Button goBackBtn, homeBtn, logoutBtn;

    @FXML
    public void switchBackHome(ActionEvent event) throws Exception {
        //this is the action of switching back to home page by pressing the HOME button
        Parent root = FXMLLoader.load(getClass().getResource("../gui/home.fxml"));
        Stage currentStage = (Stage) homeBtn.getScene().getWindow();
        currentStage.close();
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void goBackPreviousPage(ActionEvent event) throws Exception {
        //this is the action of going back to previous page the searching screen by the GO BACK button
        Parent root = FXMLLoader.load(getClass().getResource("../gui/search.fxml"));
        Stage currentStage = (Stage) goBackBtn.getScene().getWindow();
        currentStage.close();
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void logout(ActionEvent event) throws Exception {
        //this is the action of logout and back to login screen by LOGOUT button
        Parent root = FXMLLoader.load(getClass().getResource("../gui/login.fxml"));
        Stage currentStage = (Stage) logoutBtn.getScene().getWindow();
        currentStage.close();
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

   /* public ObservableValue<Artwork> getArtwork(){
        ObservableList<Artwork> artwork = FXCollections.observableArrayList();
        artwork.add(new Artwork("Example","NotreallyGood"), );
    }*/

   @FXML
     private void initialize(){
         //TODO this can help updating the result table
         /*ChangeListener<TableView> tableUpdate = ((observable, oldValue, newValue) -> {
/* resultTable.setItems(getArtwork());
         resultTable.getColumns().addAll(nameColumn, priceColumn);
         });*/
        //resultTable.getSelectionModel().selectedItemProperty().addListener(tableUpdate);
    }
}
