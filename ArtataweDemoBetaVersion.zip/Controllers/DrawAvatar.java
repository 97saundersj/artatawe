package Controllers;

import javafx.embed.swing.JFXPanel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;



/**
 * This gui class allow user to draw their own avatar with different colors, brush size and a eraser function
 *@Author Marco
 */
public class DrawAvatar {

    @FXML
    private TextField brushSize;

    @FXML
    private Button submitBtn, cancelBtn;

    @FXML
    private Canvas drawingCanvas;

    @FXML
    private ColorPicker colorPicker;

    @FXML
    private CheckBox eraser;

    public void submitAndBack(ActionEvent event)throws Exception{
        //This is the action for Submit button, user can submit the avatar by this button
        //TODO need to be able to store the avatar to image view
        Stage currentStage = (Stage) submitBtn.getScene().getWindow();
        currentStage.close();
    }
    public void cancelAndShutDown(ActionEvent event)throws Exception{
        //This is the action for Cancel button, user can shut down the drawing page by this button
        Stage currentStage = (Stage) cancelBtn.getScene().getWindow();
        currentStage.close();
    }

    public void initialize(){
        //this is the tool of painting own avatar for user
        GraphicsContext g = drawingCanvas.getGraphicsContext2D();
        drawingCanvas.setOnMouseDragged(e ->{
            double size = Double.parseDouble(brushSize.getText());
            double x = e.getX() - size / 2;
            double y = e.getY() - size / 2;
            if(eraser.isSelected()){
                g.clearRect(x, y, size, size);
            }else{
                g.setFill(colorPicker.getValue());
                g.fillRoundRect(x, y, size, size, size, size);
            }
        });
    }
}
