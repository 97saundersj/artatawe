package Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import javax.swing.*;


/**
 * This is the page for viewing an artwork with detail
 * @Author Marco
 * //TODO placebid, add favourite user and artworks , image not yet displayed, need to get information from database
 * //TODO it should be two way for linking this page, one is from result page, one is from favourite artwork on the list in Profile gui
 */
public class ArtworkView {

    @FXML
    private ImageView artworkImage;

    @FXML
    private Button placeBidBtn, closeBtn, addFavUserBtn, addFavArtBtn;

    @FXML
    public void closeWindow(ActionEvent event)throws Exception{
        //This is the action for Close button, user can close current window by this action
        Stage currentStage = (Stage) closeBtn.getScene().getWindow();
        currentStage.close();
    }

    @FXML
    public void addFavUser_Action(ActionEvent event)throws Exception{
        //TODO add favourite user
    }

    @FXML
    public void setAddFavArt_Action(ActionEvent event)throws Exception{
        //TODO add favourite artwork
    }

    @FXML
    public void placeBid_Action(ActionEvent event)throws Exception{
        //TODO place for the Bid , add to the list
    }

    @FXML
    private void initialize(){

    }
}
