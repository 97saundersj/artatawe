package Controllers;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import sample.Database;

public class buildInAvatar {
    Database database;
    public void setDatabase(Database database) {
        this.database = database;
    }

    @FXML
    private ImageView default1, default2, default3, default4, default5, drawAvatar;

    @FXML
    private Button cancelBtn, submitBtn;


    @FXML
    public void cancelAndShutDown()throws Exception{
        //This is the action for Cancel button, user can shut down the build in avatar page by this button
        Stage currentStage = (Stage) cancelBtn.getScene().getWindow();
        currentStage.close();
    }

    @FXML
    public void imageSelectMouseClick(MouseEvent e)throws Exception{
        System.out.println("clicked");
        //TODO store user's decision to database?
        ((Node) (e.getSource())).getScene().getWindow().hide();
    }
}
