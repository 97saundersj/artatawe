package Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.xml.soap.Text;

/**
 *This is the gui for users to edit their avatar in different way
 * @Author Marco
 */
public class EditProfile {

    @FXML
    private TextField firstNameText, lastNameText, phoneNoText, postCodeText;

    @FXML
    private TextArea addressText;

    @FXML
    private Button defaultAvatarBtn, drawAvatarBtn, ownAvatarButton, doneBtn;

    @FXML
    public void uploadAvatar(ActionEvent event)throws Exception{
        //This is the action for browsing the image from local system
        Stage stage = new Stage();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Image File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Images", "*.*"),
                new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("PNG", "*.png")
        );
        fileChooser.showOpenDialog(stage);
    }

    @FXML
    public void goDrawPage(ActionEvent event)throws Exception{
        //This is the action for Draw avatar button, user can draw avatar by this button
        Parent root = FXMLLoader.load(getClass().getResource("../gui/draw.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void doneAndClose(ActionEvent event)throws Exception {
        //when a user press Done button, the profile data will be changed
        //TODO need to update profile
        Stage currentStage = (Stage) doneBtn.getScene().getWindow();
        currentStage.close();
    }

    @FXML
    private void initialize(){

    }
}
