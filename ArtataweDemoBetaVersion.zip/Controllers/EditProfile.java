package Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import sample.Database;

import javax.xml.soap.Text;

/**
 *This is the gui for users to edit their avatar in different way
 * @Author Marco
 */
public class EditProfile {
    Database database;
    public void setDatabase(Database database) {
        this.database = database;
    }

    @FXML
    private TextField firstNameText, lastNameText, phoneNoText, postCodeText;

    @FXML
    private TextArea addressText;

    @FXML
    private Button defaultAvatarBtn, drawAvatarBtn, ownAvatarButton, doneBtn, cancelBtn;

    @FXML
    private ImageView avatar;

    @FXML
    public void uploadAvatar()throws Exception{
        //This is the action for browsing the image from local system
        Stage stage = new Stage();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Image File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Images", "*.*"),
                new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("PNG", "*.png")
        );
        fileChooser.showOpenDialog(stage);
    }

    @FXML
    public void goDrawPage()throws Exception{
        //This is the action for Draw avatar button, user can draw avatar by this button
        Parent root = FXMLLoader.load(getClass().getResource("../gui/draw.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void doneAndClose()throws Exception {
        //when a user press Done button, the profile data will be changed
        //TODO need to update profile
        Stage currentStage = (Stage) doneBtn.getScene().getWindow();
        currentStage.close();
    }

    @FXML
    public void cancelAndShutDown()throws Exception{
        //This is the action for Cancel button, user can shut down the drawing page by this button
        Stage currentStage = (Stage) cancelBtn.getScene().getWindow();
        currentStage.close();
    }

    @FXML
    public void goToBuildInAvatar()throws Exception{
        //This is the action for default avatar button, user can set default avatar by this button
        Parent root = FXMLLoader.load(getClass().getResource("../gui/defaultAvatar.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void removeAvatar()throws Exception{
        //this is the action for removing avatar and back to default
        System.out.println("clicked");
    Image defaultAvatar = new Image(getClass().getResourceAsStream("../images/defaultAvatar.png"));
    avatar.setImage(defaultAvatar);
    }

    @FXML
    private void initialize(){

    }
}
